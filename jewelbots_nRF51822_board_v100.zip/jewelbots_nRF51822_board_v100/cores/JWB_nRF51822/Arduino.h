#ifndef ARDUINO_H_
#define ARDUINO_H_

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#endif
