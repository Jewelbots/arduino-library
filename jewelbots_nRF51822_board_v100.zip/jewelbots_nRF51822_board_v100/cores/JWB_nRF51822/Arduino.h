#ifndef ARDUINO_H_
#define ARDUINO_H_

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* sketch */
extern void setup( void ) ;
extern void loop( void ) ;

#endif
