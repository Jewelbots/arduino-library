/* Copyright (c) 2016 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */


#ifndef NFC_NDEF_MSG_PARSER_LOCAL_H__
#define NFC_NDEF_MSG_PARSER_LOCAL_H__

/**@file
 *
 * @defgroup nfc_ndef_msg_parser_local NDEF message parser (internal)
 * @{
 * @ingroup  nfc_ndef_msg_parser
 *
 * @brief    Internal part of the parser for NFC NDEF messages.
 *
 */

#include <stdint.h>
#include "nfc_ndef_msg.h"
#include "nfc_ndef_record_parser.h"

/**
 * @brief Type for holding descriptors that are used by the NDEF parser.
 */
typedef struct
{
    nfc_ndef_msg_desc_t         * p_msg_desc;     ///< Pointer to the message descriptor.
    nfc_ndef_bin_payload_desc_t * p_bin_pay_desc; ///< Pointer to the array of binary payload descriptors.
    nfc_ndef_record_desc_t      * p_rec_desc;     ///< Pointer to the array of record descriptors.
}  nfc_ndef_parser_memo_desc_t;

/**
 * @brief Memory allocated for a one-record message.
 */
typedef struct
{
    nfc_ndef_msg_desc_t         msg_desc;
    nfc_ndef_record_desc_t    * p_record_desc_array[1];
    nfc_ndef_bin_payload_desc_t bin_pay_desc[1];
    nfc_ndef_record_desc_t      rec_desc[1];
} parsed_ndef_msg_1_t;

/**
 * @brief Memory allocated for a two-record message.
 */
typedef struct
{
    nfc_ndef_msg_desc_t         msg_desc;
    nfc_ndef_record_desc_t    * p_record_desc_array[2];
    nfc_ndef_bin_payload_desc_t bin_pay_desc[2];
    nfc_ndef_record_desc_t      rec_desc[2];
} parsed_ndef_msg_2_t;

/**
 * @brief Amount of memory that is required per record in addition to the memory allocated for the message descriptor.
 */
#define NFC_PARSER_M_DELTA (sizeof(parsed_ndef_msg_2_t) - sizeof(parsed_ndef_msg_1_t))


/**
 * @brief Function for resolving data instances in the provided buffer according
 * to requirements of the function @ref internal_ndef_msg_parser.
 *
 * This internal function distributes the provided memory between certain data instances that are required
 * by @ref internal_ndef_msg_parser.
 *
 * This function should not be used directly.
 *
 * @param[in] p_result_buf         Pointer to the buffer that will be used to allocate
 *                                 data instances.
 * @param[in,out] p_result_buf_len As input: size of the buffer specified by @p p_result_buf.
 *                                 As output: size of the reserved (used) part of the buffer specified by
 *                                 @p p_result_buf.
 * @param[out] p_parser_memo_desc  Pointer to the structure for holding descriptors of the allocated data
 *                                 instances.
 *
 * @retval NRF_SUCCESS             If the function completed successfully.
 * @retval NRF_ERROR_NO_MEM        If the provided buffer is too small to hold a one-record message.
 */
ret_code_t ndef_parser_memo_resolve(uint8_t                     * const p_result_buf,
                                    uint32_t                    * const p_result_buf_len,
                                    nfc_ndef_parser_memo_desc_t * const p_parser_memo_desc);


/**
 * @brief Function for parsing NFC NDEF messages.
 *
 * This internal function parses NDEF messages into certain data instances.
 *
 * This function should not be used directly.
 *
 * @param[in,out] p_parser_memo_desc Pointer to the structure that holds descriptors of the allocated data
 *                                   instances for the parser. This structure contains the following fields: @n
 *                                   .p_msg_desc      Pointer to the message descriptor that will
 *                                                    be filled with parsed data. @n
 *                                   .p_bin_pay_desc  Pointer to the array of binary payload
 *                                                    descriptors that will be filled with parsed
 *                                                    data. @n
 *                                   .p_rec_desc      Pointer to the array of record descriptors
 *                                                    that will be filled with parsed data. @n
 *                                   The arrays specified by @p .p_bin_pay_desc and @p .p_rec_desc must not
 *                                   contain more elements than the  message descriptor
 *                                   specified by \p .p_msg_desc can hold.
 *
 * @param[in]     p_nfc_data      Pointer to the data to be parsed.
 * @param[in,out] p_nfc_data_len  As input: size of the NFC data in the @p p_nfc_data buffer.
 *                                As output: size of the parsed message.
 *
 * @retval NRF_SUCCESS               If the function completed successfully.
 * @retval NRF_ERROR_INVALID_LENGTH  If the expected message length is bigger than the amount of provided input data.
 * @retval NRF_ERROR_INVALID_DATA    If the message is not a valid NDEF message.
 * @retval NRF_ERROR_NO_MEM          If the provided memory resources are too small to hold the parsing result.
 */
ret_code_t internal_ndef_msg_parser(nfc_ndef_parser_memo_desc_t * const p_parser_memo_desc,
                                    uint8_t                     const * p_nfc_data,
                                    uint32_t                    * const p_nfc_data_len);

/**
 * @}
 */

#endif // NFC_NDEF_MSG_PARSER_LOCAL_H__
