# arduino-library
This is the arduino library that works with the Jewelbots device
