#ifndef ARDUINO_H_
#define ARDUINO_H_

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#include "JWB_API.h"

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

/* sketch */
extern void setup( void ) ;
extern void loop( void ) ;

#ifdef __cplusplus
}
#endif

#endif
