
#ifndef __LED_H__
#define __LED_H__

class LED {
public:
  void on(uint8_t number, char *color, uint8_t length);
private:
  void color_lookup(char *color);
};

#endif
