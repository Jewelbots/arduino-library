
#ifndef __LED_H__
#define __LED_H__



#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

#include <stdbool.h>
#include <stdint.h>

class LED {
public:
  LED();
  ~LED();   
  void on(uint8_t number, char *color, uint8_t length);
private:
  void color_lookup(char *color);
};


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
