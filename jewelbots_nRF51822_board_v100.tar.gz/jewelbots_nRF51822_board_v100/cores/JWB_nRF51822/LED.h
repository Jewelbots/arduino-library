
#ifndef __LED_H__
#define __LED_H__


#ifdef __cplusplus
extern "C"{
#endif // __cplusplus


class LED {

};

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif
