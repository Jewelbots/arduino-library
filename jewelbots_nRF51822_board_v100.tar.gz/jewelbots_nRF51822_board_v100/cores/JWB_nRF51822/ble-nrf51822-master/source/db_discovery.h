#ifndef DB_DISCOVERY_H
#define DB_DISCOVERY_H


#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
void db_discovery_init(void);

#ifdef __cplusplus
}
#endif // __cplusplus
#endif
