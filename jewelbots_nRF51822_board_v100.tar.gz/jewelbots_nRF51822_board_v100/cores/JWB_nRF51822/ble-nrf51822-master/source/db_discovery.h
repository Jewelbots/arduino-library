#ifndef DB_DISCOVERY_H
#define DB_DISCOVERY_H
void db_discovery_init(void);
#endif
