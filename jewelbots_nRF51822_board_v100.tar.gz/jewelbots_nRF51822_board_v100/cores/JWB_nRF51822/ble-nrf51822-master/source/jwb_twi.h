#ifndef __JWB_TWI_H__
#define __JWB_TWI_H__

#include "nrf_drv_twi.h"

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

void twi_init();

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus
#endif
