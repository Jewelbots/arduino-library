
#include "Arduino.h"
#include "button_press.h"

void button_press() {

}

void button_press_long() {

}

void charging_button_press() {

}

void charging_button_press_long() {

}
