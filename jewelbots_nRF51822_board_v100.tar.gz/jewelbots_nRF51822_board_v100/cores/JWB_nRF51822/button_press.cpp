
#include "Arduino.h"
#include "button_press.h"

// If Jewelbots code uses a c++ function it needs to be inside below
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

void button_press() {

}

void button_press_long() {

}

void charging_button_press() {

}

void charging_button_press_long() {

}

#ifdef __cplusplus
}
#endif
