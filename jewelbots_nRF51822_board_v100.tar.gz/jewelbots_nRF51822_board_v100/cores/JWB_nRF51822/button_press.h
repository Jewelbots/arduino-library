#ifndef BUTTON_PRESS_H_
#define BUTTON_PRESS_H_

void button_press(void);
void button_press_long(void);
void charging_button_press(void);
void charging_button_press_long(void);

#endif
